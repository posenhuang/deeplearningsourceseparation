timit-wav/test/dr4/fadg0  (female) 
	TEST: SA1
	DEV: SI649
timit-wav/test/dr4/mbns0  (male)
	TEST: SA2
	DEV: SI590

The test mixture is mixed at 0 dB SNR.
